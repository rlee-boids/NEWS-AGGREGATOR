import HomePage from '../components/HomePage';

const IndexPage = () => {
  return <HomePage />;
};

export default IndexPage;