import LoginPage from '../components/LoginPage';

const IndexPage = () => {
  return <LoginPage />;
};

export default IndexPage;