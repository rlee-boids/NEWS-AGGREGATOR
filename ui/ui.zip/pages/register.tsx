import RegisterPage from '../components/RegisterPage';

const RegisterIndex = () => {
  return <RegisterPage />;
};

export default RegisterIndex;