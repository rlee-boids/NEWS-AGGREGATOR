import { useState, useEffect } from 'react';
import NewsList from '../components/NewsList';
import FilterSearch from '../components/FilterSearch';
import { useRouter } from 'next/router';

interface Article {
  id: number;
  title: string;
  summary: string;
  state: string;
  topic: string;
  date: string;
}

export default function HomePage() {
  const [user, setUser] = useState<any>(null);
  const [articles, setArticles] = useState<Article[]>([]);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [filters, setFilters] = useState<{ state: string; topic: string; search: string }>({
    state: '',
    topic: '',
    search: ''
  });
  const router = useRouter();

  // Fetch articles with pagination and filters
  const fetchArticles = async (page: number, newFilters: typeof filters = filters) => {
    if (!user) return; // Ensure `user` is loaded before fetching articles

    setLoading(true);
    try {
      let { state, topic, search } = newFilters;
      state = state || user.states;
      topic = topic || user.topics;

      let response = await fetch(
        `http://localhost:5000/news?state=${state}&topic=${topic}&search=${search}&page=${page}&limit=10`
      );
      let data = await response.json();
      if (data.length === 0) {
        console.log("No articles found in the database, fetching from external source...");
        const externalResponse = await fetch(`http://localhost:5000/news/external?state=${state}&topic=${topic}`);
        const externalData = await externalResponse.json();

        response = await fetch(
          `http://localhost:5000/news?state=${state}&topic=${topic}&search=${search}&page=${page}&limit=10`
        );
        data = await response.json();

        if (externalData.success) {
          console.log("External articles successfully fetched and stored in the database.");
        }
      }

      if (data.length < 10) {
        setHasMore(false);
      }

      setArticles((prevArticles) => (page === 1 ? data : [...prevArticles, ...data]));
    } catch (error) {
      console.error("Error fetching articles:", error);
    } finally {
      setLoading(false);
    }
  };

  // Fetch user data and call fetchArticles when filters change
  useEffect(() => {
    const storedUser = sessionStorage.getItem('user');
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);
    } else {
      router.push('/login');
    }
  }, []);

  useEffect(() => {
    if (user) {
      fetchArticles(1, filters); // Reset to first page on new filter
      setPage(1);
      setHasMore(true);
    }
  }, [filters, user]);

  // Infinite scroll handler
  useEffect(() => {
    const handleScroll = () => {
      if (window.innerHeight + document.documentElement.scrollTop >= document.documentElement.offsetHeight - 50) {
        if (!loading && hasMore) {
          setPage((prevPage) => prevPage + 1);
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [loading, hasMore]);

  useEffect(() => {
    if (page > 1) {
      fetchArticles(page, filters);
    }
  }, [page]);

  const handleFilterChange = (newFilters: { state: string; topic: string; search: string }) => {
    setFilters(newFilters);
  };

  const handleArticleClick = (id: number) => {
    router.push(`/${id}`);
  };

  const handleLogout = () => {
    sessionStorage.removeItem('user');
    router.push('/login');
  };

  return (
    <div>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem', backgroundColor: '#007bff', color: '#fff' }}>
        <h1>State Affairs - News Aggregator</h1>
        {user && (
          <div>
            <span>Welcome, {user.username}!</span>
            <button onClick={handleLogout} style={{ marginLeft: '1rem', background: 'none', color: 'white', border: '1px solid white', padding: '0.5rem', cursor: 'pointer' }}>
              Logout
            </button>
          </div>
        )}
      </header>

      <FilterSearch onFilterChange={handleFilterChange} user={user}/>
      <NewsList articles={articles} onArticleClick={handleArticleClick} />
      {loading && <p>Loading more articles...</p>}
      {!hasMore && <p>No more articles to load.</p>}
    </div>
  );
}
