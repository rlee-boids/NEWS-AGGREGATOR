import React, { useState, useEffect } from 'react';
import { Form, Button, Row, Col } from 'react-bootstrap';

interface User {
  id: number;
  username: string;
}

interface FilterSearchProps {
  onFilterChange: (filters: { state: string; topic: string; search: string }) => void;
  user: User | null;
}

const FilterSearch: React.FC<FilterSearchProps> = ({ onFilterChange, user }) => {
  const [filters, setFilters] = useState({ state: '', topic: '', search: '' });
  const [states, setStates] = useState<string[]>([]);
  const [topics, setTopics] = useState<string[]>([]);

  useEffect(() => {
    if (!user) return;

    const fetchStates = async () => {
      try {
        const response = await fetch(`http://localhost:5000/news/states?userId=${user.id}`);
        const data = await response.json();
        setStates(Array.isArray(data) ? data : []); // Ensure `data` is an array
      } catch (error) {
        console.error('Failed to fetch states:', error);
        setStates([]); // Fallback to an empty array
      }
    };

    const fetchTopics = async () => {
      try {
        const response = await fetch(`http://localhost:5000/news/topics?userId=${user.id}`);
        const data = await response.json();
        console.log('Fetched topics:', data); // Log the response for debugging
        setTopics(Array.isArray(data) ? data : []); // Ensure `data` is an array
      } catch (error) {
        console.error('Failed to fetch topics:', error);
        setTopics([]); // Fallback to an empty array
      }
    };

    fetchStates();
    fetchTopics();
  }, [user]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const handleSearch = () => {
    onFilterChange(filters);
  };

  return (
    <Form className="mb-4">
  <Row className="g-2 align-items-end">
    {/* State Dropdown */}
    <Col xs={12} md={3}>
      <Form.Group controlId="stateSelect">
        <Form.Label>State</Form.Label>
        <Form.Select name="state" value={filters.state} onChange={handleChange}>
          <option value="">Select State</option>
          {states.map((state) => (
            <option key={state} value={state}>
              {state}
            </option>
          ))}
        </Form.Select>
      </Form.Group>
    </Col>

    {/* Topic Dropdown */}
    <Col xs={12} md={3}>
      <Form.Group controlId="topicSelect">
        <Form.Label>Topic</Form.Label>
        <Form.Select name="topic" value={filters.topic} onChange={handleChange}>
          <option value="">Select Topic</option>
          {topics.map((topic) => (
            <option key={topic} value={topic}>
              {topic}
            </option>
          ))}
        </Form.Select>
      </Form.Group>
    </Col>

    {/* Search Input */}
    <Col xs={12} md={3}>
      <Form.Group controlId="searchInput">
        <Form.Label>Keyword</Form.Label>
        <Form.Control
          type="text"
          name="search"
          placeholder="Search"
          value={filters.search}
          onChange={handleChange}
        />
      </Form.Group>
    </Col>

    {/* Search Button */}
    <Col xs={12} md={3} className="d-grid">
      <Button variant="primary" onClick={handleSearch}>
        Search
      </Button>
    </Col>
  </Row>
</Form>
  );
};

export default FilterSearch;
